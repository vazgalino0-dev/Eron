﻿import os
import sys
from datetime import datetime
from groq import Groq
from memory.database import (
    init_db,
    get_controlled_context,
    add_fact,
    get_study_topic,
    save_study_progress,
    save_session_message,
    list_recent_sessions,
    load_session_messages
)
from tools.file_tool import (
    listar_workspace,
    ler_ficheiro,
    escrever_ficheiro
)


MODEL_ID = "openai/gpt-oss-120b"


def load_file_text(path, fallback=""):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    return fallback


def build_system_message(study_topic=None):
    base_prompt = load_file_text(
        os.path.join("core", "system_prompt.txt"),
        "És o Eron, um assistente pessoal direto, pragmático e leal."
    )
    memory_context = get_controlled_context(max_chars=1200)
    
    parts = [base_prompt]
    if memory_context:
        parts.append(memory_context)
        
    if study_topic:
        study_instructions = load_file_text(os.path.join("core", "study_prompt.txt"))
        existing = get_study_topic(study_topic)
        study_block = [study_instructions, f"Tema atual: {study_topic}"]
        if existing:
            study_block.append(f"Histórico prévio neste tema -> Nível: {existing[1]} | Última revisão: {existing[2]} | Notas: {existing[3]}")
        else:
            study_block.append("Histórico prévio: Primeira sessão sobre este tema.")
        parts.append("\n".join(study_block))
        
    return "\n\n".join(parts)


def main():
    print("=== A inicializar o Eron ===")
    init_db()
    
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        print("\nAviso: Chave da API da Groq não encontrada nas variáveis de ambiente.")
        api_key = input("Introduz a tua chave da Groq API: ").strip()
        if not api_key:
            print("Chave inválida. A encerrar.")
            sys.exit(1)


    client = Groq(api_key=api_key)
    
    session_id = datetime.now().strftime("sessao_%Y%m%d_%H%M%S")
    current_study_topic = None
    messages = [{"role": "system", "content": build_system_message()}]
    
    print(f"\n[Eron online | ID da Sessão: {session_id}]")
    print("Comandos:")
    print("  'sair'                  -> Terminar sessão")
    print("  '/facto <texto>'        -> Guardar facto validado na memória")
    print("  '/estudo <tema>'        -> Entrar no Modo Estudo controlado")
    print("  '/sair_estudo'          -> Sair do Modo Estudo e registar progresso")
    print("  '/sessoes'              -> Listar sessões recentes gravadas")
    print("  '/retomar <id>'         -> Carregar contexto de sessão anterior")
    print("  '/workspace'            -> Listar ficheiros na pasta segura")
    print("  '/ler <ficheiro>'       -> Ler ficheiro do workspace")
    print("  '/escrever <nome> | <c>'> Escrever ficheiro com confirmação (s/n)\n")


    while True:
        try:
            prompt_label = f"Galeano [Estudo: {current_study_topic}] > " if current_study_topic else "Galeano > "
            user_input = input(prompt_label).strip()
            if not user_input:
                continue
                
            if user_input.lower() == "sair":
                print("Eron > Até já, Galeano.")
                break


            # Comando: Guardar facto validado
            if user_input.startswith("/facto "):
                novo_facto = user_input[7:].strip()
                if novo_facto:
                    confirm = input(f"[Confirmar gravação no SQLite: '{novo_facto}'? (s/n)]: ").strip().lower()
                    if confirm == "s":
                        add_fact(novo_facto, category="manual", source="validado_humano")
                        messages[0]["content"] = build_system_message(current_study_topic)
                        print("[Memória] Facto guardado e contexto atualizado.\n")
                    else:
                        print("[Memória] Gravação cancelada.\n")
                continue


            # Comando: Listar workspace
            if user_input.lower() == "/workspace":
                files = listar_workspace()
                if not files:
                    print("\n[Workspace] A pasta está vazia.\n")
                else:
                    print(f"\n[Workspace] Ficheiros disponíveis ({len(files)}):")
                    for f in files:
                        print(f"  - {f}")
                    print()
                continue


            # Comando: Ler ficheiro
            if user_input.startswith("/ler "):
                fname = user_input[5:].strip()
                try:
                    conteudo = ler_ficheiro(fname)
                    if conteudo is not None:
                        print(f"\n=== CONTEÚDO DE {fname} ===\n{conteudo}\n==========================\n")
                    else:
                        print(f"\n[Aviso] Ficheiro '{fname}' não encontrado no workspace.\n")
                except Exception as e:
                    print(f"\n[Erro] {e}\n")
                continue


            # Comando: Escrever ficheiro com preview e confirmação (s/n)
            if user_input.startswith("/escrever "):
                partes = user_input[10:].split("|", 1)
                if len(partes) != 2:
                    print("\n[Aviso] Formato inválido. Usa: /escrever <nome.txt> | <conteúdo>\n")
                    continue
                fname = partes[0].strip()
                content = partes[1].strip()
                
                # Preview curto
                preview = (content[:100] + "...") if len(content) > 100 else content
                print(f"\n--- PREVIEW DA ESCRITA ---")
                print(f"Destino: workspace/{fname}")
                print(f"Conteúdo: {preview}")
                print("--------------------------")
                
                confirm = input(f"Confirmar escrita do ficheiro? (s/n): ").strip().lower()
                if confirm == "s":
                    try:
                        saved_path = escrever_ficheiro(fname, content)
                        print(f"[Workspace] Ficheiro gravado com sucesso em: {saved_path}\n")
                    except Exception as e:
                        print(f"[Erro de gravação] {e}\n")
                else:
                    print("[Workspace] Escrita cancelada pelo utilizador.\n")
                continue


            # Comando: Listar sessões recentes
            if user_input.lower() == "/sessoes":
                sessoes = list_recent_sessions(limit=5)
                if not sessoes:
                    print("\n[Histórico] Ainda não existem sessões anteriores gravadas.\n")
                else:
                    print("\n=== ÚLTIMAS SESSÕES GRAVADAS ===")
                    for s_id, s_time, first_msg, count in sessoes:
                        preview = (first_msg[:50] + "...") if first_msg and len(first_msg) > 50 else (first_msg or "Sem mensagens")
                        print(f"  ID: {s_id} | Início: {s_time} | Msgs: {count} | Início: '{preview}'")
                    print("Usa '/retomar <ID>' para carregar uma sessão.\n")
                continue


            # Comando: Retomar sessão anterior
            if user_input.startswith("/retomar "):
                target_id = user_input[9:].strip()
                loaded_msgs = load_session_messages(target_id, max_messages=20)
                if not loaded_msgs:
                    print(f"\n[Aviso] Nenhuma mensagem encontrada para o ID '{target_id}'.\n")
                else:
                    messages = [{"role": "system", "content": build_system_message(current_study_topic)}] + loaded_msgs
                    print(f"\n[Histórico] Sessão '{target_id}' carregada ({len(loaded_msgs)} mensagens injetadas no contexto atual).\n")
                continue


            # Comando: Entrar no Modo Estudo
            if user_input.startswith("/estudo "):
                tema = user_input[8:].strip()
                if tema:
                    current_study_topic = tema
                    messages[0]["content"] = build_system_message(current_study_topic)
                    print(f"\n[Modo Estudo ATIVO: '{current_study_topic}']\n")
                    user_msg = f"Quero estudar o tema: {current_study_topic}. Começa com a primeira explicação curta e 1 ou 2 perguntas de verificação."
                    messages.append({"role": "user", "content": user_msg})
                    save_session_message(session_id, "user", user_msg)
                else:
                    print("[Aviso] Indica o tema. Exemplo: /estudo Redes Neurais\n")
                    continue


            # Comando: Sair do Modo Estudo com gravação validada
            elif user_input.lower() == "/sair_estudo":
                if not current_study_topic:
                    print("[Aviso] Não estás no Modo Estudo neste momento.\n")
                    continue
                
                print(f"\n[A encerrar Modo Estudo: '{current_study_topic}']")
                confirm = input("Queres registar/atualizar este tema na tabela study_progress? (s/n): ").strip().lower()
                if confirm == "s":
                    nivel = input("Nível atual (ex: Iniciante / Intermédio / Avançado) [Iniciante]: ").strip() or "Iniciante"
                    notas = input("Nota curta sobre o que aprendeste: ").strip()
                    save_study_progress(current_study_topic, nivel, notas)
                    print("[Memória] Progresso de estudo guardado com sucesso.\n")
                else:
                    print("[Memória] Sessão encerrada sem alterações na base de dados.\n")
                
                current_study_topic = None
                messages[0]["content"] = build_system_message(None)
                continue
            else:
                messages.append({"role": "user", "content": user_input})
                save_session_message(session_id, "user", user_input)
            
            response = client.chat.completions.create(
                model=MODEL_ID,
                messages=messages,
                temperature=0.7,
                max_tokens=1024
            )
            
            assistant_reply = response.choices[0].message.content
            print(f"\nEron > {assistant_reply}\n")
            messages.append({"role": "assistant", "content": assistant_reply})
            save_session_message(session_id, "assistant", assistant_reply)
            
        except KeyboardInterrupt:
            print("\nEron > Sessão interrompida.")
            break
        except Exception as e:
            print(f"\n[Erro na ligação: {e}]\n")


if __name__ == "__main__":
    main()

﻿import sqlite3
import os


DB_PATH = os.path.join("memory", "eron.db")


def inspect_db():
    if not os.path.exists(DB_PATH):
        print("Base de dados ainda não existe.")
        return


    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()


    print("\n=== PERFIL ===")
    for row in cursor.execute("SELECT key, value, updated_at FROM profile"):
        print(f"[{row[0]}] {row[1]} (Atualizado: {row[2]})")


    print("\n=== FACTOS VALIDADOS ===")
    facts = cursor.execute("SELECT id, category, fact, source, created_at FROM facts").fetchall()
    if not facts:
        print("(Nenhum facto guardado ainda)")
    for row in facts:
        print(f"#{row[0]} [{row[1]}] {row[2]} | Fonte: {row[3]} ({row[4]})")


    print("\n=== PROGRESSO DE ESTUDO ===")
    studies = cursor.execute("SELECT topic, level, last_reviewed, notes FROM study_progress").fetchall()
    if not studies:
        print("(Nenhum tópico de estudo registado ainda)")
    for row in studies:
        print(f"- {row[0]} [{row[1]}] | Última revisão: {row[2]} | Notas: {row[3]}")


    conn.close()


if __name__ == "__main__":
    inspect_db()

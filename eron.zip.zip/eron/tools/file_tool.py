﻿import os


WORKSPACE_DIR = "workspace"
ALLOWED_EXTENSIONS = {".txt", ".md"}
MAX_FILE_SIZE_BYTES = 100 * 1024  # 100 KB


def ensure_workspace():
    """Garante que a pasta workspace existe."""
    if not os.path.exists(WORKSPACE_DIR):
        os.makedirs(WORKSPACE_DIR)


def safe_path(filename):
    """Garante que o caminho fica estritamente dentro de workspace/ com extensão válida."""
    ensure_workspace()
    clean_name = os.path.basename(filename)
    
    # Validar extensão
    _, ext = os.path.splitext(clean_name)
    if ext.lower() not in ALLOWED_EXTENSIONS:
        raise ValueError(f"Extensão não permitida ('{ext}'). Apenas são aceites: {ALLOWED_EXTENSIONS}")
        
    return os.path.join(WORKSPACE_DIR, clean_name)


def listar_workspace():
    """Lista todos os ficheiros na pasta workspace."""
    ensure_workspace()
    return os.listdir(WORKSPACE_DIR)


def ler_ficheiro(filename):
    """Lê um ficheiro do workspace."""
    path = safe_path(filename)
    if os.path.exists(path) and os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    return None


def escrever_ficheiro(filename, content):
    """Escreve ou sobreescreve um ficheiro no workspace com validação de tamanho."""
    if len(content.encode('utf-8')) > MAX_FILE_SIZE_BYTES:
        raise ValueError("O conteúdo excede o limite máximo permitido de 100 KB.")
        
    path = safe_path(filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path

﻿import sqlite3
import os
from datetime import datetime


DB_PATH = "memory/eron.db"


def get_db_connection():
    os.path.dirname(DB_PATH) and os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Tabela de perfil
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS profile (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)
    
    # Tabela de factos validados
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS facts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fact TEXT NOT NULL,
            category TEXT,
            source TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Tabela de progresso de estudo
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS study_progress (
            topic TEXT PRIMARY KEY,
            level TEXT,
            last_reviewed TIMESTAMP,
            notes TEXT
        )
    """)


    # Tabela de histórico de sessões
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.commit()
    conn.close()


def add_fact(fact, category="general", source="manual"):
    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute(
        "INSERT INTO facts (fact, category, source, created_at) VALUES (?, ?, ?, ?)",
        (fact, category, source, now)
    )
    conn.commit()
    conn.close()


def get_all_facts():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT fact, category FROM facts ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()
    return rows


def get_controlled_context(max_chars=1000):
    facts = get_all_facts()
    if not facts:
        return ""
    
    context_lines = ["\n[Factos Validados na Memória Pragmática]:"]
    current_length = len(context_lines[0])
    
    for row in facts:
        line = f"- [{row['category']}] {row['fact']}"
        if current_length + len(line) + 1 > max_chars:
            break
        context_lines.append(line)
        current_length += len(line) + 1
        
    return "\n".join(context_lines)


def get_study_topic(topic):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT topic, level, last_reviewed, notes FROM study_progress WHERE topic = ?", (topic,))
    row = cursor.fetchone()
    conn.close()
    return row


def save_study_progress(topic, level, notes):
    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("""
        INSERT INTO study_progress (topic, level, last_reviewed, notes)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(topic) DO UPDATE SET
            level = excluded.level,
            last_reviewed = excluded.last_reviewed,
            notes = excluded.notes
    """, (topic, level, now, notes))
    conn.commit()
    conn.close()


def save_session_message(session_id, role, content):
    conn = get_db_connection()
    cursor = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute(
        "INSERT INTO sessions (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
        (session_id, role, content, now)
    )
    conn.commit()
    conn.close()


def list_recent_sessions(limit=5):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT session_id, MIN(timestamp) as start_time, 
               (SELECT content FROM sessions s2 WHERE s2.session_id = sessions.session_id AND s2.role = 'user' AND s2.content NOT LIKE '/%' LIMIT 1) as first_msg,
               COUNT(*) as msg_count
        FROM sessions
        GROUP BY session_id
        ORDER BY start_time DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return rows


def load_session_messages(session_id, max_messages=20):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT role, content FROM sessions 
        WHERE session_id = ? 
        ORDER BY timestamp ASC
    """, (session_id,))
    rows = cursor.fetchall()
    conn.close()
    
    messages = []
    for row in rows:
        messages.append({"role": row["role"], "content": row["content"]})
    
    if len(messages) > max_messages:
        messages = messages[-max_messages:]
        
    return messages
